﻿using MdxLib.Model;
using SharpGL;
using SharpGL.SceneGraph;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using Whim_GEometry_Editor.Misc;

namespace Wa3Tuner.Helper_Classes
{
    public class xLine
    {
        public Vector3 one, two;
        public xLine(Vector3[] v)
        {
            one = v[0];
            two = v[1];
        }
        public xLine(Vector3 n, Vector3 f)
        {
            one = n; two = f;
        }

        internal void Negate()
        {
            one.X= -one.X;
            one.Y=-one.Y;
            one.Z=-one.Z;

            two.X= -two.X;
            two.Y= -two.Y;
            two.Z= -two.Z;
        }
    }

    public static class RayCaster
    {
        internal static List<xLine> Lines = new();
       
        public static Vector3[] GetRay(
            Vector2 mousePosition,
            Vector3 cameraPosition,
            Vector3 cameraTarget,
            Vector3 cameraUp,
            Vector2 screenSize,
            SharpGL.SceneGraph.Matrix modelMatrixSharpGL,
            OpenGL gl)
        {
            // Step 1: Viewport Space → Normalized Device Coordinates (NDC)
            Vector3 rayOrigin = GetRayOriginInNDC(mousePosition, screenSize);

            // Step 2: UnProject - Convert from NDC to World Space
            Vector3 worldRayOrigin = UnProjectToWorldSpace(rayOrigin, screenSize, gl, modelMatrixSharpGL, gl.GetProjectionMatrix());

            // Step 3: UnProject for the far plane (z = 1) to get the direction of the ray
            Vector3 worldRayEnd = UnProjectToWorldSpace(rayOrigin + new Vector3(0, 0, 1), screenSize, gl, modelMatrixSharpGL, gl.GetProjectionMatrix());

            // Step 4: Calculate the direction of the ray
            Vector3 rayDirection = worldRayEnd - worldRayOrigin;
            rayDirection = Vector3.Normalize(rayDirection);  // Normalize the direction

            // Step 5: Convert from World Space to Local Space
            Vector3 localRayOrigin = WorldToLocalSpace(worldRayOrigin, modelMatrixSharpGL);
            Vector3 localRayDirection = WorldToLocalSpace(worldRayOrigin + rayDirection, modelMatrixSharpGL) - localRayOrigin;

            // Return the local ray (origin and direction)
            return new Vector3[] { localRayOrigin, localRayOrigin + localRayDirection * 1000f };  // Arbitrary far distance
        }

        // Step 1: Convert Mouse Position to Normalized Device Coordinates (NDC)
        private static Vector3 GetRayOriginInNDC(Vector2 mousePosition, Vector2 screenSize)
        {
            float x = (2.0f * mousePosition.X) / screenSize.X - 1.0f;  // Map x from screen to NDC (-1 to 1)
            float y = 1.0f - (2.0f * mousePosition.Y) / screenSize.Y;  // Map y from screen to NDC (1 to -1)
            return new Vector3(x, y, 0);
        }

        // Step 2: UnProject - Convert from NDC to World Space
        // Step 2: UnProject - Convert from NDC to World Space
        private static Vector3 UnProjectToWorldSpace(Vector3 ndc, Vector2 screenSize, OpenGL gl, SharpGL.SceneGraph.Matrix modelMatrixSharpGL, SharpGL.SceneGraph.Matrix projectionMatrixSharpGL)
        {
            // Manually extract values from SharpGL.Matrix into a 16-element array
            double[] modelViewMatrix = new double[16];
            double[] projectionMatrix = new double[16];

            // Extracting matrix values manually (assuming it's a 4x4 matrix)
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    modelViewMatrix[i * 4 + j] = modelMatrixSharpGL[i, j]; // Extract model matrix values
                    projectionMatrix[i * 4 + j] = projectionMatrixSharpGL[i, j]; // Extract projection matrix values
                }
            }

            double[] winx = new double[1];
            double[] winy = new double[1];
            double[] winz = new double[1];

            // Convert NDC to world space by unprojecting
            int[] viewport = new int[] { 0, 0, (int)screenSize.X, (int)screenSize.Y };
            gl.UnProject(ndc.X, ndc.Y, ndc.Z, modelViewMatrix, projectionMatrix, viewport, ref winx[0], ref winy[0], ref winz[0]);

            // Return the world space position
            return new Vector3((float)winx[0], (float)winy[0], (float)winz[0]);
        }

        // Step 4: World Space to Local Space
        // Step 4: World Space to Local Space
        private static Vector3 WorldToLocalSpace(Vector3 worldPosition, SharpGL.SceneGraph.Matrix modelMatrixSharpGL)
        {
            // Manually extract values from SharpGL.Matrix into a 16-element array
            float[] modelMatrix = new float[16];

            // Extracting matrix values manually (assuming it's a 4x4 matrix)
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    modelMatrix[i * 4 + j] = (float)modelMatrixSharpGL[i, j]; // Copy values from SharpGL.Matrix
                }
            }

            // Convert float[] to System.Numerics.Matrix4x4
            Matrix4x4 modelMatrix4x4 = new Matrix4x4(
                modelMatrix[0], modelMatrix[1], modelMatrix[2], modelMatrix[3],
                modelMatrix[4], modelMatrix[5], modelMatrix[6], modelMatrix[7],
                modelMatrix[8], modelMatrix[9], modelMatrix[10], modelMatrix[11],
                modelMatrix[12], modelMatrix[13], modelMatrix[14], modelMatrix[15]
            );

            // Invert the model matrix to convert from world space to local space
            Matrix4x4.Invert(modelMatrix4x4, out Matrix4x4 invModelMatrix);

            // Apply the inverse model matrix to the world position
            return Vector3.Transform(worldPosition, invModelMatrix);
        }
    }



}
